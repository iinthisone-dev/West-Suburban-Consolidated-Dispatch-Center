const jobs = [
  {
    id: 1,
    title: "Frontend Developer",
    department: "Engineering",
    location: "New York",
    type: "Full-time",
    description:
      "We're looking for a skilled Frontend Developer to join our team and help build amazing user experiences.",
    salary: "$90,000 - $120,000",
  },
  {
    id: 2,
    title: "Product Designer",
    department: "Design",
    location: "San Francisco",
    type: "Full-time",
    description:
      "Join our design team to create beautiful and intuitive products that users love.",
    salary: "$85,000 - $110,000",
  },
  {
    id: 3,
    title: "Marketing Manager",
    department: "Marketing",
    location: "Remote",
    type: "Full-time",
    description:
      "Lead our marketing efforts and help grow our brand presence across multiple channels.",
    salary: "$75,000 - $100,000",
  },
];

// DOM elements
const jobContainer = document.getElementById("job-container");
const departmentFilter = document.getElementById("department-filter");
const locationFilter = document.getElementById("location-filter");
const searchInput = document.getElementById("search-input");
const positionSelect = document.getElementById("position");
const careerForm = document.getElementById("career-form");

// Initialize the page
function init() {
  renderJobs(jobs);
  populatePositionSelect();
  setupEventListeners();
}

// Render job cards
function renderJobs(jobsToRender) {
  jobContainer.innerHTML = "";

  if (jobsToRender.length === 0) {
    jobContainer.innerHTML =
      '<p class="no-jobs">No jobs match your criteria. Try adjusting your filters.</p>';
    return;
  }

  jobsToRender.forEach((job) => {
    const jobCard = document.createElement("div");
    jobCard.className = "job-card";
    jobCard.innerHTML = `
                    <span class="job-category">${job.department}</span>
                    <h3 class="job-title">${job.title}</h3>
                    <div class="job-location">
                        <i>📍</i> ${job.location}
                    </div>
                    <div class="job-type">
                        <i>⏱️</i> ${job.type}
                    </div>
                    <p class="job-description">${job.description}</p>
                    <div class="job-salary">${job.salary}</div>
                    <div class="job-actions">
                        <button class="btn btn-outline view-details" data-id="${job.id}">View Details</button>
                        <button class="btn apply-now" data-id="${job.id}">Apply Now</button>
                    </div>
                `;
    jobContainer.appendChild(jobCard);
  });
}

// Populate position select in application form
function populatePositionSelect() {
  // Get unique job titles
  const titles = [...new Set(jobs.map((job) => job.title))];

  titles.forEach((title) => {
    const option = document.createElement("option");
    option.value = title;
    option.textContent = title;
    positionSelect.appendChild(option);
  });
}

// Filter jobs based on selected criteria
function filterJobs() {
  const department = departmentFilter.value;
  const location = locationFilter.value;
  const searchTerm = searchInput.value.toLowerCase();

  const filteredJobs = jobs.filter((job) => {
    const matchesDepartment = !department || job.department === department;
    const matchesLocation = !location || job.location === location;
    const matchesSearch =
      !searchTerm ||
      job.title.toLowerCase().includes(searchTerm) ||
      job.description.toLowerCase().includes(searchTerm) ||
      job.department.toLowerCase().includes(searchTerm);

    return matchesDepartment && matchesLocation && matchesSearch;
  });

  renderJobs(filteredJobs);
}

// Setup event listeners
function setupEventListeners() {
  departmentFilter.addEventListener("change", filterJobs);
  locationFilter.addEventListener("change", filterJobs);
  searchInput.addEventListener("input", filterJobs);

  // Apply now button click
  document.addEventListener("click", function (e) {
    if (e.target.classList.contains("apply-now")) {
      const jobId = e.target.getAttribute("data-id");
      const job = jobs.find((j) => j.id == jobId);

      if (job) {
        positionSelect.value = job.title;
        document.getElementById("application-form").scrollIntoView({
          behavior: "smooth",
        });
      }
    }

    // View details button click
    if (e.target.classList.contains("view-details")) {
      const jobId = e.target.getAttribute("data-id");
      const job = jobs.find((j) => j.id == jobId);

      if (job) {
        alert(
          `Job Details:\n\nTitle: ${job.title}\nDepartment: ${job.department}\nLocation: ${job.location}\nType: ${job.type}\nSalary: ${job.salary}\n\nDescription: ${job.description}`
        );
      }
    }
  });

  // Form submission
  careerForm.addEventListener("submit", function (e) {
    e.preventDefault();

    // Get form values
    const firstName = document.getElementById("first-name").value;
    const lastName = document.getElementById("last-name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const position = document.getElementById("position").value;
    const resume = document.getElementById("resume").files[0];
    const coverLetter = document.getElementById("cover-letter").value;

    // In a real application, you would send this data to a server
    alert(
      `Thank you for your application, ${firstName} ${lastName}! We have received your application for the ${position} position and will review it shortly.`
    );

    // Reset form
    careerForm.reset();
  });

  // Mobile menu toggle
  const mobileMenuBtn = document.querySelector(".mobile-menu");
  const nav = document.querySelector("nav ul");

  mobileMenuBtn.addEventListener("click", function () {
    nav.style.display = nav.style.display === "flex" ? "none" : "flex";
  });
}

// Initialize the page when DOM is loaded
document.addEventListener("DOMContentLoaded", init);
