document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();

  // Get form values
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const subject = document.getElementById("subject").value;
  const message = document.getElementById("message").value;

  // Basic validation
  if (!name || !email || !message) {
    alert("Please fill in all required fields.");
    return;
  }

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert("Please enter a valid email address.");
    return;
  }

  // Show success message
  const successMessage = document.getElementById("successMessage");
  successMessage.style.display = "block";

  // Reset form
  this.reset();

  // Hide success message after 5 seconds
  setTimeout(() => {
    successMessage.style.display = "none";
  }, 5000);

  // In a real application, you would send the data to a server here
  console.log("Form submitted:", { name, email, subject, message });
});

// Add animation to form inputs on focus
const formInputs = document.querySelectorAll("input, textarea");

formInputs.forEach((input) => {
  input.addEventListener("focus", function () {
    this.parentElement.style.transform = "translateY(-5px)";
    this.parentElement.style.transition = "transform 0.3s ease";
  });

  input.addEventListener("blur", function () {
    this.parentElement.style.transform = "translateY(0)";
  });
});
